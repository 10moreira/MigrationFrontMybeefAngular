import { Injectable } from '@angular/core';

@Injectable()
export class MessageService {


  public message = null;
  constructor() { }

}
