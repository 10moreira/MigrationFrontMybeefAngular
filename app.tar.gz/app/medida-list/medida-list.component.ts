import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalComponent} from "../bootstrap/modal/modal.component";
import {MedidaService} from "../services/medida.service";
import {MessageService} from "../services/message.service";

@Component({
  selector: 'app-medida-list',
  templateUrl: './medida-list.component.html',
  styleUrls: ['./medida-list.component.css']
})
export class MedidaListComponent implements OnInit {

  medida = {};
  medidaDelete = null;
  message = null;
  @ViewChild(ModalComponent)
  modal:ModalComponent;

  constructor(private medidaService: MedidaService, private messageService: MessageService) {
    this.message = this.messageService.message
  }


  medidaKeys(){
    return Object.keys(this.medida);
  }


    deletamedida(id) {

        this.medidaService.destroy(id)
            .subscribe(() => {
            });
    }



    ngOnInit() {

    this.medidaService.query()
        .subscribe(data => this.medida = data)
  }

/*
  destroy(){
    this.medidaService.destroy(+this.medidaDelete.medida_id).subscribe(() => {
      //const  index = this.medidas.indexOf(this.medidaDelete);
      //this.medidas.splice(index, 1);
    });
  }
*/

  openModal(medidas){
    this.deletamedida(medidas);
    this.medidaDelete = medidas;
    this.modal.open()
  }



}
