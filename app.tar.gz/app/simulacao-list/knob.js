$(function() {
    $(".dial").knob({
        'change' : function (v) { $("#counter").text(Math.round(v)); }
    });
});