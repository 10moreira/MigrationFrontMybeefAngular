import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulacao-list',
  templateUrl: './simulacao-list.component.html',
  styleUrls: ['./simulacao-list.component.css']
})
export class SimulacaoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
