import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalComponent} from "../bootstrap/modal/modal.component";
import {CustoService} from "../services/custo.service";
import {MessageService} from "../services/message.service";

@Component({
  selector: 'app-custo-list',
  templateUrl: './custo-list.component.html',
  styleUrls: ['./custo-list.component.css']
})
export class CustoListComponent implements OnInit {


  custo = {};
  custoDelete = null;
  message = null;
  @ViewChild(ModalComponent)
  modal: ModalComponent;

  constructor(private custoService: CustoService, private messageService: MessageService) {
    this.message = this.messageService.message

  }

  custoKeys(){
    return Object.keys(this.custo);
  }

    deletacusto(id) {

        this.custoService.destroy(id)
            .subscribe(() => {
            });
    }



  ngOnInit() {
    this.custoService.query()
        .subscribe(data => this.custo = data)
  }

  destroy(){
    this.custoService.destroy(+this.custoDelete.custo).subscribe(() =>{
      //qconst index = this.custo.indexOf(this.custoDelete);
      //this.custo.splice(index, 1);
      this.modal.close();
    });
  }

  openModal(custo){

    this.deletacusto(custo);
    this.custoDelete = custo;
    this.modal.open()
  }

}
