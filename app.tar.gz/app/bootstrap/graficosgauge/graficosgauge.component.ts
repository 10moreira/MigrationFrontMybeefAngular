import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graficosgauge',
  templateUrl: './graficosgauge.component.html',
  styleUrls: ['./graficosgauge.component.css']
})
export class GraficosgaugeComponent implements OnInit {


constructor() {

}


ngOnInit() {

}


}
