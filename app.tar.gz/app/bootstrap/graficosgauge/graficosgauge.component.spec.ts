import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GraficosgaugeComponent } from './graficosgauge.component';

describe('GraficosgaugeComponent', () => {
  let component: GraficosgaugeComponent;
  let fixture: ComponentFixture<GraficosgaugeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GraficosgaugeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GraficosgaugeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
