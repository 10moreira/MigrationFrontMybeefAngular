import {Component, OnInit, ViewChild} from '@angular/core';
import {CategoriaanimalService} from "../services/categoriaanimal.service";
import {ModalComponent} from "../bootstrap/modal/modal.component";
import {MessageService} from "../services/message.service";
import {ActivatedRoute, Router} from "@angular/router";


@Component({
  selector: 'app-categoriaanimal-list',
  templateUrl: './categoriaanimal-list.component.html',
  styleUrls: ['./categoriaanimal-list.component.css']
})
export class CategoriaanimalListComponent implements OnInit {


      categoria = {};
      categoriaDelete = null;
      message = null;
      @ViewChild(ModalComponent)
      modal: ModalComponent;


   // Object = this.categoria;


  constructor(private categoriaService: CategoriaanimalService, private router: Router,
              private route: ActivatedRoute, private messageService:MessageService) {
            this.message = this.messageService.message
  }

  categoriaKeys(){
      return Object.keys(this.categoria)
  }


    deletacategoria(id) {

       this.categoriaService.destroy(id)
           .subscribe(() => {
           //for (let key of this.categoriaKeys()) {
             //  if (this.categoria[key].id == this.categoria) {
               //    delete this.categoria[key];

                   //this.messageService.message = 'Categoria Deletada com sucesso'
                   //this.router.navigate(['/categorias'])
               //}
           //}

      });
  }

  ngOnInit(){

      this.categoriaService.query()
      .subscribe(data => this.categoria = data);

  }


  openModal(categoria){

      this.deletacategoria(categoria);
      this.categoriaDelete = this.categoria;
      this.modal.open();
      //this.router.navigate(['/categorias'])

      //const index = this.categoriaKeys().indexOf(this.categoriaDelete);

  }

}
