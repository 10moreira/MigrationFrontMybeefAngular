import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conhecamybeef',
  templateUrl: './conhecamybeef.component.html',
  styleUrls: ['./conhecamybeef.component.css']
})
export class ConhecamybeefComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
