import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulacao-save',
  templateUrl: './simulacao-save.component.html',
  styleUrls: ['./simulacao-save.component.css']
})
export class SimulacaoSaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
