export class Receita {
    id:number;
    propriedade_id:number;
    data: string;
    quantidade: number;
    peso: number;
    preco: number;

}