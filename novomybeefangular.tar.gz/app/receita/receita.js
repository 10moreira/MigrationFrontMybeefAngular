"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Receita = /** @class */ (function () {
    function Receita() {
    }
    return Receita;
}());
exports.Receita = Receita;
//# sourceMappingURL=receita.js.map