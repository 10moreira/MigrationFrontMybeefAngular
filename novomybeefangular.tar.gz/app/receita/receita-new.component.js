"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var receita_service_1 = require("./receita.service");
var ReceitaNewComponent = /** @class */ (function () {
    function ReceitaNewComponent(receitaservice, router) {
        this.receitaservice = receitaservice;
        this.router = router;
        this.receita = {
            id: 0,
            propriedade_id: 1,
            data: '2',
            quantidade: 3,
            peso: 4,
            preco: 5
        };
    }
    ReceitaNewComponent.prototype.submit = function () {
        this.receitaservice.createReceita(this.receita);
        this.router.navigate(['receita', 'new']);
    };
    ReceitaNewComponent = __decorate([
        core_1.Component({
            selector: 'receita-new',
            templateUrl: 'receita-new.component.html',
            moduleId: module.id
        }),
        __metadata("design:paramtypes", [receita_service_1.ReceitaService,
            router_1.Router])
    ], ReceitaNewComponent);
    return ReceitaNewComponent;
}());
exports.ReceitaNewComponent = ReceitaNewComponent;
//# sourceMappingURL=receita-new.component.js.map