import {MessageService} from "../message.service";
import {Injectable} from "@angular/core";
import {Receita} from "./receita";

let RECEITA: Receita[] = [
    {id: 1, propriedade_id: 1, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000},
    {id: 2, propriedade_id: 2, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000},
    {id: 3, propriedade_id: 3, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000},
    {id: 4, propriedade_id: 4, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000},
    {id: 5, propriedade_id: 6, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000},
    {id: 6, propriedade_id: 7, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000}


];

@Injectable()
export class ReceitaService {

    constructor(private messageService: MessageService){}

    getReceitas(): Receita[] {

        return RECEITA;
    }

    getReceita(id: number): Receita|null{

        let array = this.getReceitas().filter(item => item.id == id);
        return array.length ? array[0] : null;

    }

    createReceita(receita: Receita){
        receita.id = this.getReceitas().length +1;
        this.getReceitas().push(receita);
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Receita incluida'
        });
    }

    deleteReceita(id: number){
        let index = this.getReceitas().findIndex(item => item.id == id);
        if(index != -1){
            this.getReceitas().splice(index, 1);
        }
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Receita excluida'
        });
    }

}
