import {Component} from "@angular/core";
import {Router} from "@angular/router";
import {Receita} from "./receita";
import {ReceitaService} from "./receita.service";


declare var module: any;

@Component({

    selector: 'receita-new',
    templateUrl: 'receita-new.component.html',
    moduleId: module.id

})

export class ReceitaNewComponent{

    receita: Receita= {
        id: 0,
        propriedade_id: 1,
        data: '2',
        quantidade: 3,
        peso: 4,
        preco: 5
    };

    constructor(
        private receitaservice: ReceitaService,
        private router: Router
    ){}

    submit(){
        this.receitaservice.createReceita(this.receita);
        this.router.navigate(['receita', 'new']);
    }

}