"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var message_service_1 = require("../message.service");
var core_1 = require("@angular/core");
var RECEITA = [
    { id: 1, propriedade_id: 1, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 },
    { id: 2, propriedade_id: 2, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 },
    { id: 3, propriedade_id: 3, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 },
    { id: 4, propriedade_id: 4, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 },
    { id: 5, propriedade_id: 6, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 },
    { id: 6, propriedade_id: 7, data: '22/07/2016', quantidade: 200, peso: 10.000, preco: 25.000 }
];
var ReceitaService = /** @class */ (function () {
    function ReceitaService(messageService) {
        this.messageService = messageService;
    }
    ReceitaService.prototype.getReceitas = function () {
        return RECEITA;
    };
    ReceitaService.prototype.getReceita = function (id) {
        var array = this.getReceitas().filter(function (item) { return item.id == id; });
        return array.length ? array[0] : null;
    };
    ReceitaService.prototype.createReceita = function (receita) {
        receita.id = this.getReceitas().length + 1;
        this.getReceitas().push(receita);
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Receita incluida'
        });
    };
    ReceitaService.prototype.deleteReceita = function (id) {
        var index = this.getReceitas().findIndex(function (item) { return item.id == id; });
        if (index != -1) {
            this.getReceitas().splice(index, 1);
        }
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Receita excluida'
        });
    };
    ReceitaService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [message_service_1.MessageService])
    ], ReceitaService);
    return ReceitaService;
}());
exports.ReceitaService = ReceitaService;
//# sourceMappingURL=receita.service.js.map