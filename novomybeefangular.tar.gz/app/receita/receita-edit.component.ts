import {Component, OnInit} from "@angular/core";
import {Receita} from "./receita";
import {ReceitaService} from "./receita.service";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {MessageService} from "../message.service";


declare var module: any;

@Component({
    selector: 'receita-edit',
    templateUrl: 'receita-edit.component.html',
    moduleId: module.id
})

export class ReceitaEditComponent implements OnInit{

    receita:Receita;


    constructor(
        private receitaService: ReceitaService,
        private route: ActivatedRoute,
        private router: Router,
        private messageService: MessageService
    ){}

    submit(){
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Receita alterada com sucesso'
        });
        this.router.navigate(['receita', 'list']);
    }

    ngOnInit(): void {

        this.route.params.forEach((params: Params) => {
            let id = +params['id'];
            this.receita = this.receitaService.getReceita(id);
            if(!this.receita){
                alert('receita não existe');
            }
        });

    }

}