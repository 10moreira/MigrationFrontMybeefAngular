import {Component, OnInit} from "@angular/core";
import {Receita} from "./receita";
import {ReceitaService} from "./receita.service";
import {Router} from "@angular/router";


declare var  module: any;


@Component({
    selector: 'receita-list',
    templateUrl: 'receita-list.component.html',
    moduleId: module.id
})

export class ReceitaListComponent implements OnInit{

    receita:Receita[];
    selectedReceita:Receita;


    constructor(private receit: ReceitaService , private router: Router){}

    goToEdit(id: number){
        this.router.navigate(['receita', id, 'edit']);
    }

    deleteReceita(id: number){
        this.receit.getReceita(id);
    }


    ngOnInit(): void {
        this.receita = this.receit.getReceitas();
    }

}