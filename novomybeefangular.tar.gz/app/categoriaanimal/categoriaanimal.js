"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CategoriaAnimal = /** @class */ (function () {
    function CategoriaAnimal() {
    }
    return CategoriaAnimal;
}());
exports.CategoriaAnimal = CategoriaAnimal;
//# sourceMappingURL=categoriaanimal.js.map