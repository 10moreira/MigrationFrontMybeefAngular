import {Component, OnInit} from "@angular/core";
import {Custo} from "./custo";
import {CustoService} from "./custo.service";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {MessageService} from "../message.service";


declare var module: any;

@Component({
    selector: 'custo-edit',
    templateUrl: 'custo-edit.component.html',
    moduleId: module.id
})

export class CustoEditComponent implements OnInit{

    custo:Custo;


    constructor(
        private custoService: CustoService,
        private route: ActivatedRoute,
        private router: Router,
        private messageService: MessageService
    ){}

    submit(){
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Custo alterado com sucesso'
        });
        this.router.navigate(['custo', 'list']);
    }

    ngOnInit(): void {

        this.route.params.forEach((params: Params) => {
            let id = +params['id'];
            this.custo = this.custoService.getCustos(id);
            if(!this.custo){
                alert('Custo não existe');
            }
        });

    }

}