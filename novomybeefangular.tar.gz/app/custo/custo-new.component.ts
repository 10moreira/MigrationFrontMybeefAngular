import {Component} from "@angular/core";
import {Custo} from "./custo";
import {CustoService} from "./custo.service";
import {Router} from "@angular/router";


declare var module: any;

@Component({

    selector: 'custo-new',
    templateUrl: 'custo-new.component.html',
    moduleId: module.id

})

export class CustoNewComponent{

    custo: Custo= {
        id: 0,
        propriedade_id: 1,
        categoriaanimal_id: 2,
        data: '3',
        valor: 4,
    };

    constructor(
        private custoService: CustoService,
        private router: Router
    ){}

    submit(){
        this.custoService.createCusto(this.custo);
        this.router.navigate(['custo', 'new']);
    }

}