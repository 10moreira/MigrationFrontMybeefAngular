import {Component, OnInit} from "@angular/core";
import {Custo} from "./custo";
import {CustoService} from "./custo.service";
import {Router} from "@angular/router";


declare var  module: any;


@Component({
    selector: 'custo-list',
    templateUrl: 'custo-list.component.html',
    moduleId: module.id
})

export class CustoListComponent implements OnInit{

    custo:Custo[];
    selectedCusto:Custo;


    constructor(private custos: CustoService, private router: Router){}

    goToEdit(id: number){
        this.router.navigate(['custo', id, 'edit']);
    }

    deleteCusto(id: number){
        this.custos.getCustos(id);
    }


    ngOnInit(): void {
        this.custo = this.custos.getCusto();
    }

}