export class Custo {
    id:number;
    propriedade_id:number;
    categoriaanimal_id:number;
    data:string;
    valor:number;

}