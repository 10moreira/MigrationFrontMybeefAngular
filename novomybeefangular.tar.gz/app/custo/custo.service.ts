import {Custo} from "./custo";
import {Injectable} from "@angular/core";
import {MessageService} from "../message.service";


let CUSTO: Custo[] = [
    {id: 1, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000},
    {id: 2, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000},
    {id: 3, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000},
    {id: 4, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000},
    {id: 5, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000},
    {id: 6, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000}

];


@Injectable()
export class CustoService {

    constructor(private messageService: MessageService){}

    getCusto(): Custo[] {

        return CUSTO;
    }

    getCustos(id: number): Custo|null{

        let array = this.getCusto().filter(item => item.id == id);
        return array.length ? array[0] : null;

    }

    createCusto(custo: Custo){
        custo.id = this.getCusto().length +1;
        this.getCusto().push(custo);
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Custo incluido'
        });
    }

    deleteCusto(id: number){
        let index = this.getCusto().findIndex(item => item.id == id);
        if(index != -1){
            this.getCusto().splice(index, 1);
        }
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Custo excluido'
        });
    }

}


