"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Custo = /** @class */ (function () {
    function Custo() {
    }
    return Custo;
}());
exports.Custo = Custo;
//# sourceMappingURL=custo.js.map