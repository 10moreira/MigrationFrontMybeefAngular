"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var message_service_1 = require("../message.service");
var CUSTO = [
    { id: 1, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 },
    { id: 2, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 },
    { id: 3, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 },
    { id: 4, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 },
    { id: 5, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 },
    { id: 6, propriedade_id: 2, categoriaanimal_id: 4, data: '22/06/2015', valor: 23.000 }
];
var CustoService = /** @class */ (function () {
    function CustoService(messageService) {
        this.messageService = messageService;
    }
    CustoService.prototype.getCusto = function () {
        return CUSTO;
    };
    CustoService.prototype.getCustos = function (id) {
        var array = this.getCusto().filter(function (item) { return item.id == id; });
        return array.length ? array[0] : null;
    };
    CustoService.prototype.createCusto = function (custo) {
        custo.id = this.getCusto().length + 1;
        this.getCusto().push(custo);
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Custo incluido'
        });
    };
    CustoService.prototype.deleteCusto = function (id) {
        var index = this.getCusto().findIndex(function (item) { return item.id == id; });
        if (index != -1) {
            this.getCusto().splice(index, 1);
        }
        this.messageService.messages.push({
            type: 'sucess',
            message: 'Custo excluido'
        });
    };
    CustoService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [message_service_1.MessageService])
    ], CustoService);
    return CustoService;
}());
exports.CustoService = CustoService;
//# sourceMappingURL=custo.service.js.map