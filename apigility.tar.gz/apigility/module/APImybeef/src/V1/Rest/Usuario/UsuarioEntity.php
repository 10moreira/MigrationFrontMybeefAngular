<?php
namespace APImybeef\V1\Rest\Usuario;

use ArrayObject;

class UsuarioEntity extends ArrayObject
{
}
