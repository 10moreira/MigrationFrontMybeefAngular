<?php
namespace APImybeef\V1\Rest\Atividade;

use ArrayObject;

class AtividadeEntity extends ArrayObject
{
}
