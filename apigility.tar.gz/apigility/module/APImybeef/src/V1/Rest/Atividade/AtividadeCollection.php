<?php
namespace APImybeef\V1\Rest\Atividade;

use Zend\Paginator\Paginator;

class AtividadeCollection extends Paginator
{
}
