<?php
namespace APImybeef\V1\Rest\Rebanho;

use ArrayObject;

class RebanhoEntity extends ArrayObject
{
}
