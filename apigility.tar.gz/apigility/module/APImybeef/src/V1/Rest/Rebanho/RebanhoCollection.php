<?php
namespace APImybeef\V1\Rest\Rebanho;

use Zend\Paginator\Paginator;

class RebanhoCollection extends Paginator
{
}
