<?php
namespace APImybeef\V1\Rest\Custo;

use ArrayObject;

class CustoEntity extends ArrayObject
{
}
