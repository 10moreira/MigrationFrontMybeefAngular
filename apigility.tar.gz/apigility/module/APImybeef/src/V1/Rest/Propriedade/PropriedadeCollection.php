<?php
namespace APImybeef\V1\Rest\Propriedade;

use Zend\Paginator\Paginator;

class PropriedadeCollection extends Paginator
{
}
