<?php
namespace APImybeef\V1\Rest\Receita;

use ArrayObject;

class ReceitaEntity extends ArrayObject
{
}
