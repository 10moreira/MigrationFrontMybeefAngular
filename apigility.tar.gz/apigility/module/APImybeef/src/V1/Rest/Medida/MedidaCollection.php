<?php
namespace APImybeef\V1\Rest\Medida;

use Zend\Paginator\Paginator;

class MedidaCollection extends Paginator
{
}
