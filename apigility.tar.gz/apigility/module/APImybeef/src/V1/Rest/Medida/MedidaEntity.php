<?php
namespace APImybeef\V1\Rest\Medida;

use ArrayObject;

class MedidaEntity extends ArrayObject
{
}
