<?php
namespace APImybeef\V1\Rest\CategoriaAnimal;

use Zend\Paginator\Paginator;

class CategoriaAnimalCollection extends Paginator
{
}
