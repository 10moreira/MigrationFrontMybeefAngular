<?php
namespace APImybeef\V1\Rest\CategoriaAnimal;

use ArrayObject;

class CategoriaAnimalEntity extends ArrayObject
{
    public $id;
    public $nome;


    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    public function getnome()
    {
        return $this->nome;
    }

    public function setnome()
    {
        $this->nome = nome;
        return $this;
    }



}
