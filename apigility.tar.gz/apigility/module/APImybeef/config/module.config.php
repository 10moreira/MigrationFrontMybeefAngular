<?php
return [
    'router' => [
        'routes' => [
            'ap-imybeef.rest.atividade' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/atividade[/:atividade_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Atividade\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.categoria-animal' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/categoria_animal[/:categoria_animal_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.custo' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/custo[/:custo_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Custo\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.medida' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/medida[/:medida_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Medida\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.propriedade' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/propriedade[/:propriedade_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Propriedade\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.rebanho' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/rebanho[/:rebanho_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Rebanho\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.receita' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/receita[/:receita_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Receita\\Controller',
                    ],
                ],
            ],
            'ap-imybeef.rest.usuario' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/usuario[/:usuario_id]',
                    'defaults' => [
                        'controller' => 'APImybeef\\V1\\Rest\\Usuario\\Controller',
                    ],
                ],
            ],
        ],
    ],
    'zf-versioning' => [
        'uri' => [
            0 => 'ap-imybeef.rest.atividade',
            1 => 'ap-imybeef.rest.categoria-animal',
            2 => 'ap-imybeef.rest.custo',
            3 => 'ap-imybeef.rest.medida',
            4 => 'ap-imybeef.rest.propriedade',
            5 => 'ap-imybeef.rest.rebanho',
            6 => 'ap-imybeef.rest.receita',
            7 => 'ap-imybeef.rest.usuario',
        ],
    ],
    'zf-rest' => [
        'APImybeef\\V1\\Rest\\Atividade\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Atividade\\AtividadeResource',
            'route_name' => 'ap-imybeef.rest.atividade',
            'route_identifier_name' => 'atividade_id',
            'collection_name' => 'atividade',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Atividade\AtividadeEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Atividade\AtividadeCollection::class,
            'service_name' => 'atividade',
        ],
        'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource',
            'route_name' => 'ap-imybeef.rest.categoria-animal',
            'route_identifier_name' => 'categoria_animal_id',
            'collection_name' => 'categoria_animal',
            'entity_http_methods' => [
                0 => 'PUT',
                1 => 'PATCH',
                2 => 'GET',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
                2 => 'DELETE',
            ],
            'collection_query_whitelist' => [],
            'page_size' => '25',
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\CategoriaAnimal\CategoriaAnimalEntity::class,
            'collection_class' => \APImybeef\V1\Rest\CategoriaAnimal\CategoriaAnimalCollection::class,
            'service_name' => 'categoria_animal',
        ],
        'APImybeef\\V1\\Rest\\Custo\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Custo\\CustoResource',
            'route_name' => 'ap-imybeef.rest.custo',
            'route_identifier_name' => 'custo_id',
            'collection_name' => 'custo',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Custo\CustoEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Custo\CustoCollection::class,
            'service_name' => 'custo',
        ],
        'APImybeef\\V1\\Rest\\Medida\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Medida\\MedidaResource',
            'route_name' => 'ap-imybeef.rest.medida',
            'route_identifier_name' => 'medida_id',
            'collection_name' => 'medida',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Medida\MedidaEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Medida\MedidaCollection::class,
            'service_name' => 'medida',
        ],
        'APImybeef\\V1\\Rest\\Propriedade\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Propriedade\\PropriedadeResource',
            'route_name' => 'ap-imybeef.rest.propriedade',
            'route_identifier_name' => 'propriedade_id',
            'collection_name' => 'propriedade',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Propriedade\PropriedadeEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Propriedade\PropriedadeCollection::class,
            'service_name' => 'propriedade',
        ],
        'APImybeef\\V1\\Rest\\Rebanho\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Rebanho\\RebanhoResource',
            'route_name' => 'ap-imybeef.rest.rebanho',
            'route_identifier_name' => 'rebanho_id',
            'collection_name' => 'rebanho',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Rebanho\RebanhoEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Rebanho\RebanhoCollection::class,
            'service_name' => 'rebanho',
        ],
        'APImybeef\\V1\\Rest\\Receita\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Receita\\ReceitaResource',
            'route_name' => 'ap-imybeef.rest.receita',
            'route_identifier_name' => 'receita_id',
            'collection_name' => 'receita',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Receita\ReceitaEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Receita\ReceitaCollection::class,
            'service_name' => 'receita',
        ],
        'APImybeef\\V1\\Rest\\Usuario\\Controller' => [
            'listener' => 'APImybeef\\V1\\Rest\\Usuario\\UsuarioResource',
            'route_name' => 'ap-imybeef.rest.usuario',
            'route_identifier_name' => 'usuario_id',
            'collection_name' => 'usuario',
            'entity_http_methods' => [
                0 => 'GET',
                1 => 'PATCH',
                2 => 'PUT',
                3 => 'DELETE',
                4 => 'POST',
            ],
            'collection_http_methods' => [
                0 => 'GET',
                1 => 'POST',
            ],
            'collection_query_whitelist' => [],
            'page_size' => 25,
            'page_size_param' => null,
            'entity_class' => \APImybeef\V1\Rest\Usuario\UsuarioEntity::class,
            'collection_class' => \APImybeef\V1\Rest\Usuario\UsuarioCollection::class,
            'service_name' => 'usuario',
        ],
    ],
    'zf-content-negotiation' => [
        'controllers' => [
            'APImybeef\\V1\\Rest\\Atividade\\Controller' => 'HalJson',
            'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Custo\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Medida\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Propriedade\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Rebanho\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Receita\\Controller' => 'Json',
            'APImybeef\\V1\\Rest\\Usuario\\Controller' => 'Json',
        ],
        'accept_whitelist' => [
            'APImybeef\\V1\\Rest\\Atividade\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Custo\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Medida\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Propriedade\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Rebanho\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Receita\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Usuario\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/hal+json',
                2 => 'application/json',
            ],
        ],
        'content_type_whitelist' => [
            'APImybeef\\V1\\Rest\\Atividade\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Custo\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Medida\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Propriedade\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Rebanho\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Receita\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
            'APImybeef\\V1\\Rest\\Usuario\\Controller' => [
                0 => 'application/vnd.ap-imybeef.v1+json',
                1 => 'application/json',
            ],
        ],
    ],
    'zf-hal' => [
        'metadata_map' => [
            \APImybeef\V1\Rest\Atividade\AtividadeEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.atividade',
                'route_identifier_name' => 'atividade_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Atividade\AtividadeCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.atividade',
                'route_identifier_name' => 'atividade_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\CategoriaAnimal\CategoriaAnimalEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.categoria-animal',
                'route_identifier_name' => 'categoria_animal_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\CategoriaAnimal\CategoriaAnimalCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.categoria-animal',
                'route_identifier_name' => 'categoria_animal_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Custo\CustoEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.custo',
                'route_identifier_name' => 'custo_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Custo\CustoCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.custo',
                'route_identifier_name' => 'custo_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Medida\MedidaEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.medida',
                'route_identifier_name' => 'medida_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Medida\MedidaCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.medida',
                'route_identifier_name' => 'medida_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Propriedade\PropriedadeEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.propriedade',
                'route_identifier_name' => 'propriedade_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Propriedade\PropriedadeCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.propriedade',
                'route_identifier_name' => 'propriedade_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Rebanho\RebanhoEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.rebanho',
                'route_identifier_name' => 'rebanho_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Rebanho\RebanhoCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.rebanho',
                'route_identifier_name' => 'rebanho_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Receita\ReceitaEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.receita',
                'route_identifier_name' => 'receita_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Receita\ReceitaCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.receita',
                'route_identifier_name' => 'receita_id',
                'is_collection' => true,
            ],
            \APImybeef\V1\Rest\Usuario\UsuarioEntity::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.usuario',
                'route_identifier_name' => 'usuario_id',
                'hydrator' => \Zend\Hydrator\ArraySerializable::class,
            ],
            \APImybeef\V1\Rest\Usuario\UsuarioCollection::class => [
                'entity_identifier_name' => 'id',
                'route_name' => 'ap-imybeef.rest.usuario',
                'route_identifier_name' => 'usuario_id',
                'is_collection' => true,
            ],
        ],
    ],
    'zf-apigility' => [
        'db-connected' => [
            'APImybeef\\V1\\Rest\\Atividade\\AtividadeResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'atividade',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Atividade\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Atividade\\AtividadeResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'categoria_animal',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\CategoriaAnimal\\CategoriaAnimalResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Custo\\CustoResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'custo',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Custo\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Custo\\CustoResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Medida\\MedidaResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'medida',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Medida\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Medida\\MedidaResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Propriedade\\PropriedadeResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'propriedade',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Propriedade\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Propriedade\\PropriedadeResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Rebanho\\RebanhoResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'rebanho',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Rebanho\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Rebanho\\RebanhoResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Receita\\ReceitaResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'receita',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Receita\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Receita\\ReceitaResource\\Table',
            ],
            'APImybeef\\V1\\Rest\\Usuario\\UsuarioResource' => [
                'adapter_name' => 'adapterbasemybeef',
                'table_name' => 'usuario',
                'hydrator_name' => \Zend\Hydrator\ArraySerializable::class,
                'controller_service_name' => 'APImybeef\\V1\\Rest\\Usuario\\Controller',
                'entity_identifier_name' => 'id',
                'table_service' => 'APImybeef\\V1\\Rest\\Usuario\\UsuarioResource\\Table',
            ],
        ],
    ],
    'zf-content-validation' => [
        'APImybeef\\V1\\Rest\\Atividade\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Atividade\\Validator',
        ],
        'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\CategoriaAnimal\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Custo\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Custo\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Medida\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Medida\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Propriedade\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Propriedade\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Rebanho\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Rebanho\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Receita\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Receita\\Validator',
        ],
        'APImybeef\\V1\\Rest\\Usuario\\Controller' => [
            'input_filter' => 'APImybeef\\V1\\Rest\\Usuario\\Validator',
        ],
    ],
    'input_filter_specs' => [
        'APImybeef\\V1\\Rest\\Atividade\\Validator' => [
            0 => [
                'name' => 'descricao',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            1 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
        ],
        'APImybeef\\V1\\Rest\\CategoriaAnimal\\Validator' => [
            0 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '30',
                        ],
                    ],
                ],
            ],
        ],
        'APImybeef\\V1\\Rest\\Custo\\Validator' => [
            0 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'categoria',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            3 => [
                'name' => 'valor',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'APImybeef\\V1\\Rest\\Medida\\Validator' => [
            0 => [
                'name' => 'valor',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            1 => [
                'name' => 'ano',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
        ],
        'APImybeef\\V1\\Rest\\Propriedade\\Validator' => [
            0 => [
                'name' => 'usuario_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'cidades_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'pais_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            5 => [
                'name' => 'nro_car',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            6 => [
                'name' => 'tamanho',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            7 => [
                'name' => 'localidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
        ],
        'APImybeef\\V1\\Rest\\Rebanho\\Validator' => [
            0 => [
                'name' => 'ano',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'categoria_animal_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'qtd_estocada',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'peso_estocado',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            5 => [
                'name' => 'qtd_vendida',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            6 => [
                'name' => 'peso_vendido',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'APImybeef\\V1\\Rest\\Receita\\Validator' => [
            0 => [
                'name' => 'propriedade_id',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'data',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            2 => [
                'name' => 'quantidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            3 => [
                'name' => 'peso',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
            4 => [
                'name' => 'preco',
                'required' => false,
                'filters' => [],
                'validators' => [],
            ],
        ],
        'APImybeef\\V1\\Rest\\Usuario\\Validator' => [
            0 => [
                'name' => 'cidades_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            1 => [
                'name' => 'pais_id',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\Digits::class,
                    ],
                ],
                'validators' => [],
            ],
            2 => [
                'name' => 'login',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'adapterbasemybeef',
                            'table' => 'usuario',
                            'field' => 'login',
                        ],
                    ],
                    1 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '45',
                        ],
                    ],
                ],
            ],
            3 => [
                'name' => 'email',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => 'ZF\\ContentValidation\\Validator\\DbNoRecordExists',
                        'options' => [
                            'adapter' => 'adapterbasemybeef',
                            'table' => 'usuario',
                            'field' => 'email',
                        ],
                    ],
                    1 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            4 => [
                'name' => 'senha',
                'required' => true,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '128',
                        ],
                    ],
                ],
            ],
            5 => [
                'name' => 'perfil',
                'required' => true,
                'filters' => [],
                'validators' => [],
            ],
            6 => [
                'name' => 'nome',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            7 => [
                'name' => 'localidade',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '60',
                        ],
                    ],
                ],
            ],
            8 => [
                'name' => 'telefone',
                'required' => false,
                'filters' => [
                    0 => [
                        'name' => \Zend\Filter\StringTrim::class,
                    ],
                    1 => [
                        'name' => \Zend\Filter\StripTags::class,
                    ],
                ],
                'validators' => [
                    0 => [
                        'name' => \Zend\Validator\StringLength::class,
                        'options' => [
                            'min' => 1,
                            'max' => '20',
                        ],
                    ],
                ],
            ],
        ],
    ],
    'zf-mvc-auth' => [
        'authorization' => [
            'APImybeef\\V1\\Rest\\CategoriaAnimal\\Controller' => [
                'collection' => [
                    'GET' => false,
                    'POST' => false,
                    'PUT' => false,
                    'PATCH' => false,
                    'DELETE' => false,
                ],
                'entity' => [
                    'GET' => false,
                    'POST' => true,
                    'PUT' => false,
                    'PATCH' => true,
                    'DELETE' => false,
                ],
            ],
        ],
    ],
];
