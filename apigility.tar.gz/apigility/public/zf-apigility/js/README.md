Files in this directory
=======================

- bootstrap.min.js: Minified version of the Bootstrap 3 javascript.
- jquery.min.js: Minified version of jquery 2.0.3
