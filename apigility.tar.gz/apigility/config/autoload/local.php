<?php
return [
    'db' => [
        'adapters' => [
            'adapterbasemybeef' => [
                'database' => 'baseMybeef',
                'driver' => 'PDO_Mysql',
                'username' => 'root',
                'password' => 'mateusmoreira',
                'driver_options' => [
                    1002 => 'SET NAMES \'UTF8\'',
                ],
            ],
        ],
    ],
];
